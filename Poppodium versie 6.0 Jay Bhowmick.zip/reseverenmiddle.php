<!DOCTYPE html>
<html lang="en">
<title>Poppodium</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!--css bestand-->
<link rel="stylesheet" href="PoppodiumCSS.css">
<!-- style sheet-->
<style>
.bgimg {
  background-position: center;
  background-size: cover;
  background-image: url("b00ty.jpg");
  min-height: 75%;
}

body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif;}
body {font-size:16px;}
.-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}
.-half img:hover{opacity:1}



/* devanagari */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJbecmNE.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJnecmNE.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJfecg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
</style>
<body>

<!-- Navigatie Bar -->
<nav class="-sidebar -teal -collapse -top -large -padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
  <a href="javascript:void(0)" onclick="_close()" class="-button -hide-large -display-topleft" style="width:100%;font-size:22px">Sluit het Menu</a>
  <div class="-container">
    <h3 class="-padding-64"><b>Township<br>Poppodium</b></h3>
  </div>
  <div class="-bar-block">
    <a href="Poppodium.php" onclick="_close()" class="-bar-item -button -hover-orange">HomePage</a>  
    
  </div>
</nav>

<!-- !PAGE CONTENT! -->
<div class="-main" style="margin-left:340px;margin-right:40px">





<!-- betaal methode -->
<br/><br/><br/><br/>
<div class="-row-padding">
<form name="deal" action="Zaal.php">
<p>Kies hier uw betaalmethode: <select>
<option value="iDeal">iDeal</option>
  <option value="creditcard">creditcard</option>
</select>


<br/><br/>
<hr/>
<p>Voor iDeal selecteer bank: <select>
  <option value="ABN AMRO">ABN AMRO</option>
  <option value="creditcard">ING</option>
</select><br/><br/>
&nbsp;&nbsp;&nbsp;<button name="iDeal" class="-button -teal -padding-large -hover-orange">betalen</button>

<br/><br/>  
<hr/>


<p>Voor creditcard selecteer card: <select>
  <option value="Visa">Visa</option>
  <option value="mastercard">mastercard</option>
</select><br/><br/>
&nbsp;&nbsp;&nbsp;<button name="iDeal" class="-button -teal -padding-large -hover-orange">betalen</button>

</form>
<br/>
<?php
$uren2 = $_POST["uren2"];

if (isset($_POST["middlezaal"]))
{
    $totaal2 = $uren2 * 60;                        
echo "U heeft de Middelgrote zaal gehuurd voor:  $uren2  uur <br/>";               
echo "De prijs = $totaal2 euro <br/><br/>";  
}
?>
</div>



    




<!-- Top menu op kleine schermen -->
<header class="-container -top -hide-large -teal -xlarge -padding">
  <a href="javascript:void(0)" class="-button -teal -margin-right" onclick="_open()">☰</a>
  <span>Poppodium</span>
</header>

<!-- Overlay effect wanneer de sidebar open op kleine devices -->
<div class="-overlay -hide-large" onclick="_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>


<style>
  /* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content {
  position:fixed;
  background-color: #fefefe;
  margin:25%;
  margin-left:40%;
  margin-top:5%;
  padding: 20px;
  border: 1px solid #888;
  width: 30%; /* Could be more or less, depending on screen size */
  height:60%;
  
}

/* The Close Button */
.close {
  color: turquoise;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}
</style>

<script>
// Script to open and close navbar
function _open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function _close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";



//login button

  // Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
}

</script>
  

</div>
</body>
</html>


