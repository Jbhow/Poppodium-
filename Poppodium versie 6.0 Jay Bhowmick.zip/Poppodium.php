<!DOCTYPE html>
<!-- Website van jay, dylan en sam-->
<html lang="en">
<title>Poppodium</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="description" content="Flexible Calendar with jQuery and CSS3" />
    <meta name="keywords" content="responsive, calendar, jquery, plugin, flexible, javascript, css3, media queries" />
   


<!--css bestand-->
<link rel="stylesheet" href="PoppodiumCSS.css">
<!-- style sheet-->
<style>
.bgimg {
  background-position: center;
  background-size: cover;
  background-image: url("b00ty.jpg");
  min-height: 75%;
}

body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif;}
body {font-size:16px;}
.-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}
.-half img:hover{opacity:1}



/* devanagari Font */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJbecmNE.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext Font */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJnecmNE.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin Font */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJfecg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}


/* slide shows */
.mySlides {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position de "next button" naar rechts */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* Op hover, voegt zwarte background color met een beetje see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* voor kleiner scherm wordt de tekst kleiner */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}

 /* De Modal (achter) */
 .modal {
  display: none; /* Hidden by default */
  position: fixed; /* zit op een plek */
  z-index: 1; /* Staat boven aan */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* scrollen kan automatische ingeschakeld worden */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* zwart met opacity */
}

/* Modal Content/Box */
.modal-content {
  
  position:fixed;
  background-color: #fefefe;
  margin-top:5%;
  margin-left:50%; 
  padding: 20px;
  border: 1px solid #888;
  width: 100%;
  max-width: 300px;
  height:60;
  
}


/* voor kleiner scherm wordt de tekst kleiner */
@media only screen and (max-width: 300px) {
  .modal, .modal-content {font-size: 11px}
}

/* de Close Button */
.close {
  color: turquoise;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}



#items{
   
  overflow-x: scroll;
    width: 100%;
    white-space: nowrap;
}
  .item{
     display: inline-block;
     width: 1500px;
     height: 100px;}

     .biograph{
    Width:100%;
    max-width: 600px;
    margin-right:20%;
    margin-left:0%;
    
    }

.Video{
Height:80vh;
Width:100%;

     
  }
  </style>
<body>

<!-- Navigatie Bar -->
<nav class="-sidebar -teal -collapse -top -large -padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
  <a href="javascript:void(0)" onclick="_close()" class="-button -hide-large -display-topleft" style="width:100%;font-size:22px">Sluit het Menu</a>
  <div class="-container">
    <h3 class="-padding-64"><b>Township<br>Poppodium</b></h3>
  </div>
  <div class="-bar-block">
    <a href="#" onclick="_close()" class="-bar-item -button -hover-orange">Homepage</a>  
    <a href="#Over" onclick="_close()" class="-bar-item -button -hover-orange">Over ons</a> 
    <a href="#verhuur" onclick="_close()" class="-bar-item -button -hover-orange">Verhuur</a> 
    <a href="#Programma" onclick="_close()" class="-bar-item -button -hover-orange">Programma</a>
    <a id="myBtn" onclick="_close()" class="-bar-item -button -hover-orange">Log in</a>
  </div>
  <!--social media buttuns -->
  <div class="-container">
      <h3><b>Onze social media</b></h3>
      <div class="iconsList">
        <p><b>Volg ons:</b></p>
          <div class="icons">
            <a href="https://www.facebook.com">
            <img src="foto/Facebooklogo.png" style="width:40px; height:40px"></a>
            <a href="https://www.instagram.com">
            <img src="foto/Instragramlogo.jpg" style="width:40px; height:40px"></a>
            <a href="https://www.twitter.com">
            <img src="foto/Twitterlogo.png" style="width:40px; height:40px"></a>
            <a href="https://www.snapchat.com">
            <img src="foto/Snapchat.jpg" style="width:40px; height:40px"></a>
          </div>
      </div>
    </div>
    <br>
    <div class="-container">
      <h4><b>Word lid van de nieuwbrief</b></h4>
      <form action="nieuwbrief.php" target="_blank">
        <div class="-section">
            <label>Uw email:</label>
            <input class="-input -border" type="text" name="Email" requigrey>
          </div>
          <button type="submit" class="-button -padding-large -grey -margin-bottom">Meld u aan</button>
        </form>
    </div>
  </nav>
  


<!-- script van dylan -->
<!-- Trigger/Open The Modal -->

<button id="myBtn" onclick="_close()">Open Modal</button>
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content" margin="align-center">
    <span class="close">&times;</span>
   <h3>Log in</h3>
   
   <form method='POST' action='Goodlogin.php' >
      <td>E-mail:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="text" name="email" id="email"></td></tr><br/><br/>
      Wachtwoord:&nbsp;<input type="password" name="wachtwoord" id="wachtwoord"></td></tr>	    
     <br/> <br/>
         <tr> <td> <input type="submit" name="loginButton" id="loginButton" value="login"></td></tr>
         </form></div>
        
</div>
<!-- De style sheet voor de login button-->

<!-- Top menu op kleine schermen -->
<header class="-container -top -hide-large -teal -xlarge -padding">
  <a href="javascript:void(0)" class="-button -teal -margin-right" onclick="_open()">☰</a>
  <span>Poppodium</span>
</header>

<!-- Overlay effect wanneer de sidebar open op kleine devices -->
<div class="-overlay -hide-large" onclick="_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="-main" style="margin-left:340px;margin-right:40px">

  <!-- Header -->
  <div class="-container" style="margin-top:80px" id="showcase">
    <h1 class="-jumbo"><b>WELKOM</b></h1>
    <h1 class="-xxxlarge -text-grey"><b>Bij Poppodium</b></h1>
    
  </div>


 <div class="-row-padding">
  <p><b>De locatie voor uw muziek ervaringen</b></p>

    <!-- Photo grid (modal) -->
    <div class="row-padding">
        <div class="bgimg">
          <img src="foto/banner.jpg" style="width:100%">
        </div>
      </div>

   <!--agenda-->
   <div class="container">
      <div class="calendar light">
        <div class="calendar_header">
          <h1 class = "header_title">Events!</h1>
          <p class="header_copy">Weekplanning</p>
        </div>
        <div class="calendar_plan">
          <div class="cl_plan">
            <div class="cl_title">Vandaag</div>
            <div class="cl_copy">29 Augustus 2019<br>
            -</div>
            <div class="cl_add">
            <i class="fas fa-plus"></i>
            </div>
          </div>
        </div>
        <div class="calendar_events">
          <p class="ce_title">Aankomde events</p>
          <div class="event_item">
            <div class="ei_Dot dot_active"></div>
            <div class="ei_Title">Sevn Alias</div>
            <div class="ei_Copy">Concert van Sevn Alias<br>
            Zo 1 September, 21:00 Royal theather Carre<br>
            Koop uw tickets nu!
            </div>
          </div>
          <div class="event_item">
            <div class="ei_Dot dot_active"></div>
            <div class="ei_Title">Arianda Grande</div>
            <div class="ei_Copy">Concert van Arianda Grande<br>
            Ma 2 September, 20:00 DeLaMar theather<br>
            Laatste tickets in de verkoop!
            </div>
          </div>
          <div class="event_item">
            <div class="ei_Dot dot_active"></div>
            <div class="ei_Title">Celine Dion</div>
            <div class="ei_Copy">Concert van Celine Dion<br>
            Do 5 September, 20:30 theather Carre<br>
            Koop uw tickets nu!
            </div>
          </div>
          <div class="event_item">
            <div class="ei_Dot dot_active"></div>
            <div class="ei_Title">Ed Sheeran</div>
            <div class="ei_Copy">Concert van Ed Sheeran<br>
              Vr 6 September, 21:00 DeLaMar theather<br>
            Laatste tickets in de verkoop!
            </div>
          </div>
        </div>
      </div>
    </div>



  <!-- over ons  -->
  <div class="-container" id="Over" style="margin-top:75px">
    <h1 class="-xxxlarge -text-grey"><b>Over ons</b></h1>
  
    <h2><b>Contact</b></h2>
    <p>
      Poppodium<br/>
      Paul van Vlissingenstraat 10D<br/>
      1096 BK Amsterdam<br/>
      <br/><br/>
      Telefoon: 020 - 79 70 500<br/>
      Studio: 0909 - 9596 (45 cent per gesprek)<br/>
     <a href="mailto:info@poppodium.nl">info@poppodium.nl</a><br/>
      <br/><br/>
     <a href="www.facebook.com/poppodium">www.facebook.com/poppodium</a>
    </p>
  
    <h2><b>Route</b></h2>     
    <p>De locatie is 5 minuten van de Zuidas en de RAI, 10 minuten van het centrum van Amsterdam en 20 minutes van Schiphol.</p>
    <br/>
    <h2><b>Gevonden voorwerpen</b></h2>
    <p>Bent u iets kwijt? Neem dan contact op met onze administratie. Als het nog niet gevonden is houden wij u op de hoogte via Email.</p>
    <br/>

  <!-- Contact via mail -->
  <!-- demo@T.nl is het mail adress dat je moet gebruiker -->
      <h2><b>Stuur ons een bericht</b></h2>
      <p>Full in dit formulier om contact te maken met ons.</p>
      <form name="mailfrom"action="mailpage.php" method="POST">
        <div class="-section">
          <label>Naam</label>
          <input class="-input -border" type="text" name="Name" required name="name">
        </div>
        <div class="-section">
          <label>Email</label>
          <input class="-input -border" type="text" name="Email" required name="Email">
        </div>
        <div class="-section">
          <label>Bericht</label>
          <input class="-input -border" type="text" name="Message" required name="name">
        </div>
        <button type="submit" class="-button -block -padding-large -grey -margin-bottom">Stuur bericht</button>
      </form>  
    
<br/>

    <h2><b>Google maps</b></h2>    
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2438.0172048102036!2d4.919495315800557!3d52.333833979779385!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c60bd20175d699%3A0x11625a1981985410!2sPaul%20van%20Vlissingenstraat%2010-D%2C%201096%20BK%20Amsterdam!5e0!3m2!1sen!2snl!4v1566997436783!5m2!1sen!2snl" width="50%" height="100%" frameborder="0" style="border:0;" allowfullscreen=""></iframe>    
    <br/>
    <br/>
    <br/>
     <h2><b>Parkeren</b></h2>
    <p>Betaald parkeren is mogelijk is de Paul van Vlissingenstraat. Het is goedkoper om te parkeren bij een P+R Terrein en dan het openbaar vervoer te nemen.</p>
    
    <br/>
    <h2><b>Verbinding openbaar vervoer</b></h2>
    <p>Op <a href="https://9292.nl/">9292ov.nl</a> kunt u uw reis met het Openbaar Vervoer plannen.</p>

  


  <!-- Verhuur -->
  <h1 id=verhuur class="-xxxlarge -text-grey"><b>Verhuur</b></h1>
<div class="slideshow-container">

    <div class="mySlides fade">
      <div class="numbertext">1 / 3</div>
      
      <ul class="-ul -white -center">
          <li class="-teal -xlarge -padding-32">Kleine zaal</li>
          <br/>
          <img src="foto/Kleinezaal.jpg" alt="icon" width="38%" />
          <li class="-padding-16">Maximaal 8 uur beschikbaar</li>
          <li class="-padding-16">Muziek</li>
          <li class="-padding-16">5.1 Sound</li>
          <li class="-padding-16">200 Mensen
          </li>

          <li class="-padding-16">
              <form naam="form klein zaal" method="POST" action="reseverenklein.php">
                Aantaal uur huren <input type="number" min="1" max="8" required name="uren1">

              </li>
          <li class="-padding-16">
            <h2>€ 50,00</h2>
            <span class="-opacity">per uur</span>
          </li>
          <li class="-light-grey -padding-24">
            <button name="kleinzaal" class="-button -teal -padding-large -hover-orange">Reseveren</button>
          </form>
          </li>
        </ul>
      
      
    </div>
    
    <div class="mySlides fade">
      <div class="numbertext">2 / 3</div>

     
    <!-- Middelgrote zaal -->
        <div class=" -margin-bottom">
          <ul class="-ul -white -center">
            <li class="-teal -xlarge -padding-32">Middelgrote zaal</li>
            <br/>
            <img src="foto/Kleinezaal.jpg" alt="icon" width="38%" />
            <li class="-padding-16">16 uur beschikbaar</li>
            <li class="-padding-16">Muziek</li>
            <li class="-padding-16">7.1 Sound</li>
            <li class="-padding-16">400 Mensen
            </li>

            <li class="-padding-16">
              <form naam="form middle zaal" method="POST" action="reseverenmiddle.php">
                Aantaal uur huren <input type="number" min="1" max="8" required name="uren2">
                </li>
            <li class="-padding-16">
              <h2>€ 60,00</h2>
              <span class="-opacity">per uur</span>
            </li>
            <li class="-light-grey -padding-24">
              <button name="middlezaal" class="-button -teal -padding-large -hover-orange">Reseveren</button>
            </form>
            </li>
          </ul> 
      
      </div>
    </div>
    
    <div class="mySlides fade">
      <div class="numbertext">3 / 3</div>

      <!-- Grote zaal -->       
        <div class=" -margin-bottom">
          <ul class="-ul -white -center">
            <li class="-teal -xlarge -padding-32">Grote zaal</li>
            <br/>
            <img src="foto/Kleinezaal.jpg" alt="icon" width="38%" />
            <li class="-padding-16">24 uur beschikbaar</li>
            <li class="-padding-16">Muziek</li>
            <li class="-padding-16">9.1 Sound</li>
            <li class="-padding-16">800 Mensen</li>
            <li class="-padding-16">
              <form naam="form grote zaal" method="POST" action="reseverengroot.php">
                Aantaal uur huren <input type="number" min="1" max="8" required name="uren3">
            </li>
            <li class="-padding-16">
              <h2>€ 75,00</h2>
              <span class="-opacity">per uur</span>
            </li>
            <li class="-light-grey -padding-24">
              <button name="grootzaal" class="-button -teal -padding-large -hover-orange">Reseveren</button>
              </form>
            </li>
          </ul> 
      
      </div>
     
    </div>
    
    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>
    
    </div>
    <br>
    
    <div style="text-align:center">
      <span class="dot" onclick="currentSlide(1)"></span> 
      <span class="dot" onclick="currentSlide(2)"></span> 
      <span class="dot" onclick="currentSlide(3)"></span> 
   </div>
  
   
  
  <!-- Programma -->
  <div class="-container" id="Programma" style="margin-top:75px"></div>
    <h1 class="-xxxlarge -text-grey" ><b>Programma</b></h1>
  </div>
<!-- Biography -->
<!-- Ed Sheeran -->

  <div class="biograph">  
  <h3 style="text-align: center">Ed Sheeran</h3>
  <img class="" src="foto/ed Sheeran.jpg" alt="icon" width="100%" height="100%" />
<ul style="list-style: none">
  <li><p>Naam: Edward Christopher Sheeran</p></li>
  <li><p>leeftijd: 28 jaar</p></li>
  <li><p>Genre: Pop</p></li>
  <li><p>Treedt op:
    10-09-2019 in hoofddorp bij Pier K</p></li>

</ul>
<!-- Celine dion -->
<h3 style="text-align: center">Céline Dion</h3>
  <img class="" src="foto/Celinedion.jpg" alt="icon" width="100%" />
<ul style="list-style: none">
  <li><p>Naam: Céline Marie Claudette Dion</p></li>
  <li><p>leeftijd: 51 jaar</p></li>
  <li><p>Genre: Pop / Soft Rock</p></li>
  <li><p>Treedt op: 22-09-2019 in Amsterdam bij Royal Theatre Carré</p></li>

</ul>
<!-- Ariana Grande -->
<h3 style="text-align: center">Ariana Grande</h3>
  <img class="" src="foto/Ariane grande.jpg" alt="icon" width="100%" />
<ul style="list-style: none">
  <li><p>Naam: Ariana Grande-Butera</p></li>
  <li><p>leeftijd: 26 jaar</p></li>
  <li><p>Genre: Pop / R&B</p></li>
  <li><p>Treedt op: 10-10-2019 in Amsterdam DeLaMar Theater</p></li>

</ul>
<!-- Sevn Alias -->
<h3 style="text-align: center">Sevn Alias</h3>
  <img class="" src="foto/Sevn alias.jpg" alt="icon" width="100%" />
<ul style="list-style: none">
  <li><p>Naam: Sevaio Mook</p></li>
  <li><p>leeftijd: 23 jaar</p></li>
  <li><p>Genre: Trap / Grime / Nederhop</p></li>
  <li><p>Treedt op: 21-10-2019 in Valkenburg bij Open-air Theater Valkenburg</p></li>
</ul>
  
 <!-- Youtube video -->
 <div class="Video">
  <h2 style="text-align: center">Ariana Grande Live Concert</h2>
  <iframe width="100%" height="100%" src="https://www.youtube.com/embed/FflfOb4BWCU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>

  <br/><br/><br/><br/>

<!-- Tickets bestellen -->
<h1 class="-xxxlarge -text-grey" ><b>Bestel hier uw tickets.</b></h1>
<div class="-row-padding">

<h3>Royal Theater Carré</h3>
<img class="biograph" src="foto/Royaltheater.jpg" alt="icon"  width="100%"/>
<p>€80,-</p>

<!-- Ticket formulier 1 -->
<form name="ticket1"action="Concert.php">
<button class="-button -teal -padding-large -hover-orange">Bestel nu</button>
</form>

<h3>DeLaMar Theater</h3>
<img class="biograph" src="foto/Delamar.jpg" alt="icon"  width="100%"/>
<p>€100,-</p>

<!-- Ticket formulier 2 -->
<form name="ticket2"action="Concert2.php">
<button  class="-button -teal -padding-large -hover-orange">Bestel nu</button>
</form>

</div>

    
<!-- End page content -->
</div>
</div>

<br/><br/><br/>

<script>
// Script to open and close sidebar
function _open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function _close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
  
//login button

  // Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

}

//slide show
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}

</script>
</body>
</html>
