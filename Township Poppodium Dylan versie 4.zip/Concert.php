
<!-- Royal Theater Carré -->
<!DOCTYPE html>
<html lang="en">
<title>Poppodium</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!--css bestand-->
<link rel="stylesheet" href="PoppodiumCSS.css">
<!-- style sheet-->

<body>

<!-- Navigatie Bar -->
<nav class="-sidebar -teal -collapse -top -large -padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
  <a href="javascript:void(0)" onclick="_close()" class="-button -hide-large -display-topleft" style="width:100%;font-size:22px">Sluit het Menu</a>
  <div class="-container">
    <h3 class="-padding-64"><b>Township<br>Poppodium</b></h3>
  </div>
  <div class="-bar-block">
    <a href="Poppodium2.php" onclick="_close()" class="-bar-item -button -hover-orange">Terug naar Startpagina</a>  
     </div></nav>

     <div class="Box"> 
<p></p>
<form>

<div id="myModal" class="modal">

  <!-- Concert betalen -->
 
    
   <h3>Royal Theater Carré</h3>
   
   <form method='POST' action='' >
   <td>Hoeveel personen?<input type="number" name="" id=""></td></tr><br>
      <td>Aantal kaarten<input type="number" name="" id=""></td></tr><br>
      	    
      <br><select>
   <!-- Amsterdam Royal Theatre Carré -->
  <option value="volvo">10-09-2019 - Ed Sheeran</option>
   <!-- Amsterdam Royal Theatre Carré -->
  <option value="saab">22-09-2019 - Céline Dion</option>
  
</select>
         <tr> <td> <input type="submit" name="submit" id="" value="Bereken uw prijs"></td></tr>
         </form>

</div>


     </div>

<style>

.Box{
    Position:absolute;
    Background-color:teal;
    width:100%;
    max-width:600px;
    height:60vh;
    margin-left:35%;
    margin-top:5%;

}


.bgimg {
  background-position: center;
  background-size: cover;
  background-image: url("b00ty.jpg");
  min-height: 75%;
}

body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif;}
body {font-size:16px;}
.-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}
.-half img:hover{opacity:1}



/* devanagari */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJbecmNE.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJnecmNE.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJfecg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
</style>
</body>
</html>

