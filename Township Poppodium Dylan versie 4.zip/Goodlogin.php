<?php
//Login Enter
$enteredEmail=$_POST["email"];
$enteredPassword=$_POST["wachtwoord"];
$loggedin = $enteredEmail;

if ($enteredEmail== "carla" && $enteredPassword == "12345"){
    //Sessie word gestart.
    session_start();
 
    // Controlleert of het de juiste gebuiker is.
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: menu.php");
        echo "Sessie is actief met sessienaam: carla";

//Sessie word gesloten
exit;


}
}
//Als het fout is ingevoerd.
else{
    echo"Verkeerde login en/of wachtwoord. <br>";
    echo"Klik <a href='Opgave1.html'>Hier</a> om het opnieuw te proberen";
}
           ?>