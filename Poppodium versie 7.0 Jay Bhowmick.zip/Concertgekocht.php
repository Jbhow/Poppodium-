<!DOCTYPE html>
<!-- Website van jay, dylan en sam-->
<html lang="en">
<title>Poppodium</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
   


<!--css bestand-->
<link rel="stylesheet" href="PoppodiumCSS.css">
<!-- style sheet-->
<style>
.bgimg {
  background-position: center;
  background-size: cover;
  background-image: url("b00ty.jpg");
  min-height: 75%;
}

body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif;}
body {font-size:16px;}
.-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}
.-half img:hover{opacity:1}



/* devanagari Font */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJbecmNE.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext Font */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJnecmNE.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin Font */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJfecg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}


/* slide shows */
.mySlides {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position de "next button" naar rechts */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* Op hover, voegt zwarte background color met een beetje see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* voor kleiner scherm wordt de tekst kleiner */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
  </style>
<body>

<!-- Navigatie Bar -->
<nav class="-sidebar -teal -collapse -top -large -padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
  <a href="javascript:void(0)" onclick="_close()" class="-button -hide-large -display-topleft" style="width:100%;font-size:22px">Sluit het Menu</a>
  <div class="-container">
    <h3 class="-padding-64"><b>Township<br>Poppodium</b></h3>
  </div>
  <div class="-bar-block">
    <a href="Poppodium.php" onclick="_close()" class="-bar-item -button -hover-orange">Homepage</a>  
  </div>
  </nav>
  



<!-- Top menu op kleine schermen -->
<header class="-container -top -hide-large -teal -xlarge -padding">
  <a href="javascript:void(0)" class="-button -teal -margin-right" onclick="_open()">☰</a>
  <span>Poppodium</span>
</header>

<!-- Overlay effect wanneer de sidebar open op kleine devices -->
<div class="-overlay -hide-large" onclick="_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="-main" style="margin-left:340px;margin-right:40px">

 <div class="-row-padding">
 <br/><br/><br/>
  <p>Uw tickets zijn besteld. Geniet van uw voorstelling.
  <br/>Click op "Homepage" bij het menu om terug te gaan naar de site.</p>
  </div>
<!-- End page content -->

</div>
<br/><br/><br/>
<script>
// Script to open and close sidebar
function _open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function _close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
  
//login button

  // Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

}

//slide show
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}

</script>
</body>
</html>
