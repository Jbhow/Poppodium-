<!DOCTYPE html>
<html lang="en">
<title>Poppodium</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!--css bestand-->
<link rel="stylesheet" href="PoppodiumCSS.css">
<!-- style sheet-->
<style>
.bgimg {
  background-position: center;
  background-size: cover;
  background-image: url("b00ty.jpg");
  min-height: 75%;
}

body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif;}
body {font-size:16px;}
.-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}
.-half img:hover{opacity:1}



/* devanagari */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJbecmNE.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJnecmNE.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v8/pxiEyp8kv8JHgFVrJJfecg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
</style>
<body>

<!-- Navigatie Bar -->
<nav class="-sidebar -teal -collapse -top -large -padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
  <a href="javascript:void(0)" onclick="_close()" class="-button -hide-large -display-topleft" style="width:100%;font-size:22px">Sluit het Menu</a>
  <div class="-container">
    <h3 class="-padding-64"><b>Township<br>Poppodium</b></h3>
  </div>
  <div class="-bar-block">
    <a href="#" onclick="_close()" class="-bar-item -button -hover-orange">Startpagina</a>  
    <a href="#Over" onclick="_close()" class="-bar-item -button -hover-orange">Over ons</a> 
    <!-- a href="#contact" onclick="_close()" class="-bar-item -button -hover-orange">Contact  -->
    <a href="#verhuur" onclick="_close()" class="-bar-item -button -hover-orange">Verhuur</a> 
    <a href="#Programma" onclick="_close()" class="-bar-item -button -hover-orange">Programma</a>
    <a id="myBtn" onclick="_close()" class="-bar-item -button -hover-orange">Log in</a>
  </div>
</nav>


<!-- Trigger/Open The Modal -->
<button id="myBtn">Open Modal</button>

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
   <h3>Log in</h3>
   
   <form method='POST' action='Goodlogin.php' >
      <td>Email:<input type="text" name="email" id="email"></td></tr><br>
      Wachtwoord:<input type="password" name="wachtwoord" id="wachtwoord"></td></tr>	    
     
         <tr> <td> <input type="submit" name="loginButton" id="loginButton" value="login"></td></tr>
         </form></div>

</div>

<style>
  /* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content {
  position:fixed;
  background-color: #fefefe;
  margin:25%;
  margin-left:40%;
  margin-top:5%;
  padding: 20px;
  border: 1px solid #888;
  width: 30%; /* Could be more or less, depending on screen size */
  height:60%;
  
}

/* The Close Button */
.close {
  color: turquoise;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}



#items{
   
  
    width: 100%;
    overflow: auto;
    white-space: nowrap;
}
  .item{
     display: inline-block;
     width: 50%;
     height: 10%;
     
  }



  .biograph{
    Width:100%;

    margin-right:20%;
    margin-left:0%;
  }

.Video{
Height:80vh;
Width:100%;



}


</style>



<!-- Top menu on small screens -->
<header class="-container -top -hide-large -teal -xlarge -padding">
  <a href="javascript:void(0)" class="-button -teal -margin-right" onclick="_open()">☰</a>
  <span> Township Poppodium</span>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="-overlay -hide-large" onclick="_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="-main" style="margin-left:340px;margin-right:40px">

  <!-- Header -->
  <div class="-container" style="margin-top:80px" id="showcase">
    <h1 class="-jumbo"><b>WELKOM</b></h1>
    <h1 class="-xxxlarge -text-grey"><b>Startpagina</b></h1>
   
  </div>
  <div class="-row-padding">
<p><b>Welkom bij Poppodium.</B></p>
  <p>insert text....</p>
</div>

  <!-- Modal for full size images on click-->
  <div id="modal01" class="-modal -black" style="padding-top:0" onclick="this.style.display='none'">
    <span class="-button -black -xxlarge -display-topright">×</span>
    <div class="-modal-content -animate-zoom -center -transparent -padding-64">
      <img id="img01" class="-image">
      <p id="caption"></p>
    </div>
  </div>
   <!-- Photo grid (modal) -->
   <div class="row-padding">
      <div class="bgimg">
        <img src="b00ty.jpg" style="width:100%">
      </div>
    </div>

  <!-- over ons  -->
  <div class="-container" id="Over" style="margin-top:75px">
    <h1 class="-xxxlarge -text-grey"><b>Over ons</b></h1>
  
    <h2><b>Kontakt</b></h2>
    <p>Some text about our services - what we do and what we offer. We are lorem ipsum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
    dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor
    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
    </p>
  
    <h2><b>Route</b></h2>
     
    <p>Some text about our services - what we do and what we offer. We are lorem ipsum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
        dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor
        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </p>

  <!-- Contact via mail -->

      <h2><b>mail</b></h2>
      <p>Do you want us to style your home? Fill out the form and fill me in with the details :) We love meeting new people!</p>
      <form name="mailform" action="mailpage.php">
        <div class="-section">
          <label>Name</label>
          <input class="-input -border" type="text" name="Name" requigrey>
        </div>
        <div class="-section">
          <label>Email</label>
          <input class="-input -border" type="text" name="Email" requigrey>
        </div>
        <div class="-section">
          <label>Message</label>
          <input class="-input -border" type="text" name="Message" requigrey>
        </div>
        <button type="submit" class="-button -block -padding-large -grey -margin-bottom">Send Message</button>
      </form>  
    </div>
<br/>
    <h2><b>Google maps</b></h2>    
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d77928.43607304501!2d4.572839078777989!3d52.38377110253785!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c5ef6c60e1e9fb%3A0x8ae15680b8a17e39!2sHaarlem!5e0!3m2!1sen!2snl!4v1566931944844!5m2!1sen!2snl"
     width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>      
  
     <h2><b>parkeren</b></h2>
     
    <p>Some text about our services - what we do and what we offer. We are lorem ipsum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
        dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor
        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </p>

    <h2><b>Verbinding openbaar vervoer</b></h2>
    <p>Op <a href>9292ov.nl</a> kunt u uw reis met het Openbaar Vervoer plannen.</p>

     <h2><b>gevonden voorwerpen</b></h2>
     
    <p>Some text about our services - what we do and what we offer. We are lorem ipsum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
        dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor
        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </p>
  

  <!-- Verhuur -->
   <!-- Kleine zaal -->
  <div id="items">
    <div class="item">
  <div class="-container" id="verhuur" style="margin-top:75px">
    <h1 class="-xxxlarge -text-grey"><b>Verhuur</b></h1>
    
    <div class="-row-padding">
    <div class=" -margin-bottom">
      <ul class="-ul -white -center">
        <li class="-teal -xlarge -padding-32">Kleine zaal</li>
        
        <img src="Kleinezaal.jpg" alt="icon" width="38%" />
        <li class="-padding-16">8 uur beschikbaar</li>
        <li class="-padding-16">Muziek</li>
        <li class="-padding-16">5.1 Sound</li>
        <li class="-padding-16">200 Mensen
        </li>
        <li class="-padding-16">
          <h2>€ 50,00</h2>
          <span class="-opacity">per uur</span>
        </li>
        <li class="-light-grey -padding-24">
          <button class="-button -white -padding-large -hover-grey">Bestel nu</button>
        </li>
      </ul>
    
    </div>
    </div>
    </div>
    </div>
    <!-- Middelgrote zaal -->
    <div class="item">
    <div class="-row-padding">
    <div class=" -margin-bottom">
      <ul class="-ul -white -center">
        <li class="-teal -xlarge -padding-32">Middelgrote zaal</li>
        
        <img src="Kleinezaal.jpg" alt="icon" width="38%" />
        <li class="-padding-16">16 uur beschikbaar</li>
        <li class="-padding-16">Muziek</li>
        <li class="-padding-16">7.1 Sound</li>
        <li class="-padding-16">400 Mensen
        </li>
        <li class="-padding-16">
          <h2>€ 60,00</h2>
          <span class="-opacity">per uur</span>
        </li>
        <li class="-light-grey -padding-24">
          <button class="-button -white -padding-large -hover-grey">Bestel nu</button>
        </li>
      </ul> 
  
  </div>

    </div>
    </div>
    <!-- Grote zaal -->
    <div class="item">
    <div class="-row-padding">
    <div class=" -margin-bottom">
      <ul class="-ul -white -center">
        <li class="-teal -xlarge -padding-32">Grote zaal</li>
        
        <img src="Kleinezaal.jpg" alt="icon" width="38%" />
        <li class="-padding-16">24 uur beschikbaar</li>
        <li class="-padding-16">Muziek</li>
        <li class="-padding-16">9.1 Sound</li>
        <li class="-padding-16">800 Mensen
        </li>
        <li class="-padding-16">
          <h2>€ 75,00</h2>
          <span class="-opacity">per uur</span>
        </li>
        <li class="-light-grey -padding-24">
          <button class="-button -white -padding-large -hover-grey">Bestel nu</button>
        </li>
      </ul> 
  
  </div>

    </div>
    </div>
    
    </div>


    <p>The best team in the world.</p>
    <p>We are lorem ipsum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
    dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor
    incididunt ut labore et quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
    </p>
    <p><b>Our designers are thoughtfully chosen</b>:</p>
  

  <!-- Programma -->

  <div class="-container" id="Programma" style="margin-top:75px">
    <h1 class="-xxxlarge -text-grey" ><b>Programma</b></h1>
   
    <p>Some text our prices. Lorem ipsum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure</p>
  </div>
<!-- Biography -->
<!-- Ed Sheeran -->

  <div class="biograph">  
  <h3 style="text-align: center">Ed Sheeran</h3>
  <img class="" src="ed Sheeran.jpg" alt="icon" width="100%" height="100%" />
<ul style="list-style: none">
  <li><p>Name: Edward Christopher Sheeran</p></li>
  <li><p>Age: 28 jaar</p></li>
  <li><p>Genre: Pop</p></li>
  <li><p>Treedt op: 10-09-2019 in hoofddorp bij Pier K</p></li>

</ul>
<!-- Celine dion -->
<h3 style="text-align: center">Céline Dion</h3>
  <img class="" src="Celinedion.jpg" alt="icon" width="100%" />
<ul style="list-style: none">
  <li><p>Name: Céline Marie Claudette Dion</p></li>
  <li><p>Age: 51 jaar</p></li>
  <li><p>Genre: Pop / Soft Rock</p></li>
  <li><p>Treedt op: 22-09-2019 in Amsterdam bij Royal Theatre Carré</p></li>

</ul>
<!-- Ariana Grande -->
<h3 style="text-align: center">Ariana Grande</h3>
  <img class="" src="Ariane grande.jpg" alt="icon" width="100%" />
<ul style="list-style: none">
  <li><p>Name: Ariana Grande-Butera</p></li>
  <li><p>Age: 26 jaar</p></li>
  <li><p>Genre: Pop / R&B</p></li>
  <li><p>Treedt op: 10-10-2019 in Amsterdam DeLaMar Theater</p></li>

</ul>
<!-- Sevn Alias -->
<h3 style="text-align: center">Sevn Alias</h3>
  <img class="" src="Sevn alias.jpg" alt="icon" width="100%" />
<ul style="list-style: none">
  <li><p>Name: Sevaio Mook</p></li>
  <li><p>Age: 23 jaar</p></li>
  <li><p>Genre: Trap / Grime / Nederhop</p></li>
  <li><p>Treedt op: 21-10-2019 in Valkenburg bij Open-air Theater Valkenburg</p></li>

</ul>
  
  <!-- Youtube video -->
<div class="Video">
  <h2 style="text-align: center">Ariana Grande Live Concert</h2>
  <iframe width="100%" height="100%" src="https://www.youtube.com/embed/FflfOb4BWCU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
<!-- Tickets bestellen -->
<div class="Ticket">
<br/><br/><br/><br/>
<ul>
<li>1</li>
<li>2</li>
<li>3</li>
<li>4</li>
</ul>



</div>
</div>
<!-- End page content -->
</div>
<br/><br/><br/>

<script>
// Script to open and close navbar
function _open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function _close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";



//login button

  // Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
}


</script>

</body>
</html>
